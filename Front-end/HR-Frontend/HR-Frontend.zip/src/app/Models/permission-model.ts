export class PermissionModel {
    constructor(public id:number,public name:string , public selected :boolean){}
}
