import { EmployeeDashboard } from './employee-dashboard';

describe('EmployeeDashboard', () => {
  it('should create an instance', () => {
    expect(new EmployeeDashboard()).toBeTruthy();
  });
});
