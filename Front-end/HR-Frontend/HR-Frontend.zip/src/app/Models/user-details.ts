export class UserDetails {
    constructor(public name:string,public job_title:string,public id:string,public role_name:string,public is_clocked_out:boolean,public national_id:string,public clockIn:string,public image:string ,public work_home:boolean ,public total_hours:string){}
}


