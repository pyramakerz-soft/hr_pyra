import { PermissionAddModel } from './permission-add-model';

describe('PermissionAddModel', () => {
  it('should create an instance', () => {
    expect(new PermissionAddModel()).toBeTruthy();
  });
});
