export class AssignLocationToUser {
    constructor(
        public id: number,
        public name: string,
    ) {}
}
