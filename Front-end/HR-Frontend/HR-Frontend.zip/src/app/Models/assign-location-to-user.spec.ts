import { AssignLocationToUser } from './assign-location-to-user';

describe('AssignLocationToUser', () => {
  it('should create an instance', () => {
    expect(new AssignLocationToUser()).toBeTruthy();
  });
});
