export class Clock {
    constructor(
        public id: number,
        public formattedClockIn: string,
        public formattedClockOut: string,
        public userId :number
    ) {}
}

