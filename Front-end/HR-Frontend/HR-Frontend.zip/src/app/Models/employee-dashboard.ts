export class EmployeeDashboard {

    constructor(public Day:string , public Date :string ,public clockIn:string , public clockOut:string , public totalHours :string , public locationIn:string , public locationOut:string, public site:string , public formattedClockIn:string , public formattedClockOut:string ,public otherClocks:any[]){}

}


