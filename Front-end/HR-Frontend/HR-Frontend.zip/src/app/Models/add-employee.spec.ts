import { AddEmployee } from './add-employee';

describe('AddEmployee', () => {
  it('should create an instance', () => {
    expect(new AddEmployee()).toBeTruthy();
  });
});
