export class PermissionAddModel {
    constructor(public name:string){}

}
