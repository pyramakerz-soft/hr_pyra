import { WorkType } from './work-type';

describe('WorkType', () => {
  it('should create an instance', () => {
    expect(new WorkType()).toBeTruthy();
  });
});
