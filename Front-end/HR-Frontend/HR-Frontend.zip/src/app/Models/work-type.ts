export class WorkType {
    constructor(
        public id: number,
        public name : string
    ){} 
}
