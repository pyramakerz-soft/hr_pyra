export class Manager {
    constructor(
        public manager_id: number,
        public manager_name: string,
    ) {}
}
