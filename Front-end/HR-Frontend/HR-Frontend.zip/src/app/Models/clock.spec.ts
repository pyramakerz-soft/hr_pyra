import { Clock } from './clock';

describe('Clock', () => {
  it('should create an instance', () => {
    expect(new Clock()).toBeTruthy();
  });
});
