import { RoleModel } from './role-model';

describe('RoleModel', () => {
  it('should create an instance', () => {
    expect(new RoleModel()).toBeTruthy();
  });
});
